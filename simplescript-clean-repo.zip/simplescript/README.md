# SimpleScript

> A general-purpose programming language that reads like plain English, with the
> least punctuation that still keeps it clear — and compiles to a real program.

This is the **clean rebuild**, started from a fully-designed specification. This
first commit contains the **lexer**: the part that reads SimpleScript source and
breaks it into *tokens* — the small words and pieces every later stage works with.

## Where things are

```
simplescript/
├── go.mod
├── internal/
│   └── lexer/
│       ├── token.go        # the token types + the reserved "connector words"
│       ├── lexer.go        # turns source text into tokens
│       └── lexer_test.go   # 20 tests pinning down the tricky cases
└── cmd/
    └── sslex/
        └── main.go         # a tiny tool that prints the tokens for a program
```

## Try it

Lex the built-in demo program:

```bash
go run ./cmd/sslex
```

Lex your own file:

```bash
go run ./cmd/sslex myprogram.ss
```

Run the tests:

```bash
go test ./...
```

## How the lexer works (the one clever idea)

SimpleScript lets a **name contain spaces** — `cart total` is one name, not two.
That only works because a small, fixed set of **connector words** act as rails:
`to`, `of`, `with`, `is`, `and`, and friends. A name is simply every word *up to
the next rail*.

So `set cart total to 0` reads as:

```
SET · IDENT("cart total") · TO · NUMBER("0")
```

The lexer always prefers the **longest** reserved phrase, so `is greater than`
beats `is`, and `give back` is a single keyword. Names keep their original casing
and may use letters from **any language** (`prénom`, `имя`, `名前`) — SimpleScript
is international from the very first stage.

## What's next

The **parser** — which takes this token stream and builds the structured tree of
the program — followed by the **transpiler** that turns that tree into Go, then a
real executable. Every step is already mapped out in the specification.

## Licence

MIT (to be added).
